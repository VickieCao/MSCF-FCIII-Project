# -*- coding: utf-8 -*-
"""
Created on Fri Feb 22 11:21:20 2019

@author: ThinkPad
"""
import pandas as pd

#stock pool selection
def stockpool_select(earnings_surprise,sentdex):
    #earnings_surprise processing
    earnings_surprise['%Surprise']=earnings_surprise['%Surprise'].astype(float)
    earnings_surprise.sort_values(by='%Surprise',ascending=False,inplace=True)
    earnings_surprise = earnings_surprise[['Ticker','EPS','%Surprise']]  
    
    #sentdex processing
    sentdex.drop(0,inplace=True)
    sentdex = sentdex[['Ticker','Sentiment','Rising or Falling']]
    
    #selection
    sentdex_select = sentdex[(sentdex['Sentiment']=='very good') | (sentdex['Sentiment']=='good')]
    sentdex_select = sentdex_select[sentdex_select['Rising or Falling'] == 'up']
    ES_select = earnings_surprise[(earnings_surprise['EPS']>0) & (earnings_surprise['%Surprise']>0)]
    sentdex_ticker=set(sentdex_select['Ticker'])
    ES_ticker=set(ES_select['Ticker'])
    stockpool_Tickers=list(sentdex_ticker & ES_ticker)
    return stockpool_Tickers

if __name__ == '__main__': 
    earnings_surprise = pd.read_csv("earnings_surprise.csv")
    sentdex = pd.read_csv("sentdex.csv")
    stockpool_Tickers = stockpool_select(earnings_surprise,sentdex)