from earningsurprise_crawl import earningsurprise_crawl
from sentiment_crawl import sentiment_crawl
import pandas as pd

print("Date Range for Earnings Surprise:\n")
start_date = str(input("Start Date (YYYY-MM-DD):"))
end_date = str(input("End Date (YYYY-MM-DD):"))
earnings_dates = [(str(a)[:10]).replace('-','') for a in 
                  pd.bdate_range(start_date,end_date)]

sentdex_range = str(input("Choose sentiment timeframe (7d/30d/6m/1y):"))

esp = earningsurprise_crawl(earnings_dates)
sdx = sentiment_crawl(sentdex_range)

esp.to_csv("earnings_surprise.csv")
sdx.to_csv("sentdex.csv")