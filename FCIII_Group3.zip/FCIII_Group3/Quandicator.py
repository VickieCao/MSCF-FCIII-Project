import numpy as np
import pandas as pd
import pandas_datareader as web
from stock_pool_selection import *
from score_function import *
from port_optimization import *

def Quandicator():
    # Get the Stock Pool
    print('Getting the stock pool based on earning_surprise and sentiment data...\n')
    earnings_surprise = pd.read_csv("earnings_surprise.csv")
    sentdex = pd.read_csv("sentdex.csv")
    stockpool_Tickers = stockpool_select(earnings_surprise, sentdex)

    # Download google trends
    print('Google trend downloading (It can take a few minutes)...')
    from pytrends.request import TrendReq
    pytrends = TrendReq(hl='en-US', tz=360)
    Gtrends = pd.DataFrame([])
    for ticker in stockpool_Tickers:
        kwlist = [ticker]
        try:
            pytrends.build_payload(kwlist, cat=0, timeframe='2019-02-07 2019-02-21', geo='', gprop='')
            interest_over_time_df = pytrends.interest_over_time()
            Gtrends = pd.concat([Gtrends, interest_over_time_df[ticker]], axis=1)
        except:
            print("This ticker", kwlist, "failed!")

    Gtrends.to_csv('Google_trends.csv')
    print('Google trends dowloaded in Google_trends.csv\n')

    # Get Score for each Ticker
    print('Calculating scores for selected stocks...\n')
    score = get_score(stockpool_Tickers)
    score.to_csv('stock_score.csv')
    print('Stock scores stored in stock_score.csv\n')
    watchlist = score.sort_values(by=['Total Score'], ascending=False)
    watchlist = watchlist[['ROC Score','MFI Score', 'ARBR Score', 'Gtrends Score', 'Total Score']]
    watchlist.to_csv('watchlist.csv')
    print('Final Watch List:')
    print(watchlist)
    print('Watch List dowloaded in watchlisht.csv\n')
    Opt = input("Do you want to optimize your portfolio? (Y/N)")
    if Opt=='Y':
        port_optimization()

if __name__ == '__main__':
    Quandicator()
